#include "../include/glad/glad.h"
#include "../include/GLFW/glfw3.h"
#include "../include/glm/glm.hpp"
#include "../include/glm/gtc/matrix_transform.hpp"
#include "engine/bolts.h"
#include <vector>
#include <iostream>
#include <memory>
#include <string>

void keyboardInput(GLFWwindow* currentWindow){};

// Global helper to switch the engine's internal camera variables
void teleportCamera(glm::vec3 pos, float newYaw, float newPitch) {
    cameraPos = pos;
    yaw = newYaw;
    pitch = newPitch;
    // We don't need to set cameraFront; the engine's mouseInput
    // calculates it automatically from yaw/pitch next frame.
}

void setPrimaryVars(){
    skyboxEnabled = true;
    // Update this path to your local directory as needed
    skyboxPath = "/Users/adrianlloyd/Desktop/Work/Projects/BoltsEngine/EngineTemplate/skybox/";

    pitchLimit = -1.0;
    yawLimit = -1.0;
}

// Helper to create a 3D box by defining 6 faces
std::vector<std::shared_ptr<Shape>> createPillarMesh(float width, float height, float depth, glm::vec3 pos) {
    std::vector<std::shared_ptr<Shape>> mesh;
    float hw = width / 2.0f;
    float hd = depth / 2.0f;

    // Front Face (Z+)
    mesh.push_back(std::make_shared<Rectangle>(
            glm::vec3(pos.x - hw, pos.y + height, pos.z + hd),
            glm::vec3(pos.x + hw, pos.y,          pos.z + hd)));

    // Back Face (Z-)
    mesh.push_back(std::make_shared<Rectangle>(
            glm::vec3(pos.x - hw, pos.y + height, pos.z - hd),
            glm::vec3(pos.x + hw, pos.y,          pos.z - hd)));

    // Left Face (X-)
    mesh.push_back(std::make_shared<Rectangle>(
            glm::vec3(pos.x - hw, pos.y + height, pos.z - hd),
            glm::vec3(pos.x - hw, pos.y,          pos.z + hd)));

    // Right Face (X+)
    mesh.push_back(std::make_shared<Rectangle>(
            glm::vec3(pos.x + hw, pos.y + height, pos.z - hd),
            glm::vec3(pos.x + hw, pos.y,          pos.z + hd)));

    // Top Face (Y+)
    mesh.push_back(std::make_shared<Rectangle>(
            glm::vec3(pos.x - hw, pos.y + height, pos.z - hd),
            glm::vec3(pos.x + hw, pos.y + height, pos.z + hd)));

    // Bottom Face (Y-)
    mesh.push_back(std::make_shared<Rectangle>(
            glm::vec3(pos.x - hw, pos.y, pos.z - hd),
            glm::vec3(pos.x + hw, pos.y, pos.z + hd)));

    return mesh;
}

void createEnvironment() {
    // 1. Ground
    auto groundRect = std::make_shared<Rectangle>(
            glm::vec3(-100.0f, -2.0f, -100.0f),
            glm::vec3(100.0f, -2.0f, 100.0f)
    );
    std::vector<std::shared_ptr<Shape>> groundMesh = { groundRect };
    physicalWorld.push_back(std::make_unique<Physical>(groundMesh, glm::vec4(0.1f, 0.15f, 0.1f, 1.0f)));

    // 2. 3D Monolith
    // We create a pillar 4 units wide, 10 units high, and 4 units deep
    auto pillarMesh = createPillarMesh(4.0f, 10.0f, 4.0f, glm::vec3(0.0f, -2.0f, 0.0f));
    physicalWorld.push_back(std::make_unique<Physical>(pillarMesh, glm::vec4(0.1f, 0.1f, 0.1f, 1.0f)));
}

void update() {
    // 1. Core engine update (clears world, handles mouse/keyboard)
    engineUpdate();

    // 2. Camera Rotation Logic (5 Second Interval)
    double currentTime = glfwGetTime();
    static double lastSwitchTime = 0;
    static int cameraState = 0;

    // Only switch and "snap" the camera once every 5 seconds
    if (currentTime - lastSwitchTime >= 5.0) {
        cameraState = (cameraState + 1) % 3;
        lastSwitchTime = currentTime;

        if (cameraState == 0) {
            // Center View: Farther back (Z = 25)
            teleportCamera(glm::vec3(0.0f, 3.0f, 25.0f), -90.0f, -5.0f);
        }
        else if (cameraState == 1) {
            // Left Angle: Looking from the side
            teleportCamera(glm::vec3(-20.0f, 5.0f, 15.0f), -40.0f, -10.0f);
        }
        else {
            // Right Angle: Looking from the other side
            teleportCamera(glm::vec3(20.0f, 5.0f, 15.0f), -140.0f, -10.0f);
        }
    }

    // 3. Re-populate the world for this frame
    createEnvironment();

    // 4. Frame rendering
    engineBeginFrame();
    if (!isPaused) {
        drawScene();
    } else {
        renderPauseMenu(shaderProgram);
    }
    handleUI();
    engineEndFrame();
}

int main() {
    setPrimaryVars();

    // Setup Skybox textures using the safe string method
    std::string base = skyboxPath;
    std::string s_right = base + "right.png";
    std::string s_left = base + "left.png";
    std::string s_top = base + "top.png";
    std::string s_bottom = base + "bottom.png";
    std::string s_front = base + "front.png";
    std::string s_back = base + "back.png";

    const char* faces[6] = {
            s_right.c_str(), s_left.c_str(), s_top.c_str(),
            s_bottom.c_str(), s_front.c_str(), s_back.c_str()
    };

    startEngine();

    // Initial call to set the first camera position before the loop starts
    teleportCamera(glm::vec3(0.0f, 3.0f, 25.0f), -90.0f, -5.0f);
    // Initialize skybox with the built array
    initSkybox(faces);

    while (gameActive){
        update();
    }

    return 0;
}