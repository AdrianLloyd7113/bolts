//
// Created by Adrian Lloyd on 2025-12-23.
//

#ifndef ENGINETEMPLATE_MAIN_H
#define ENGINETEMPLATE_MAIN_H


class main {

};


#endif //ENGINETEMPLATE_MAIN_H
