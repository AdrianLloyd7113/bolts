#include "../include/glad/glad.h"
#include "../include/GLFW/glfw3.h"
#include "../include/glm/glm.hpp"
#include "../include/glm/gtc/matrix_transform.hpp"
#include "engine/bolts.h"
#include <vector>
#include <iostream>

class Asteroid{
public:
    //x, z, height
    std::vector<glm::vec3> spikes;
    std::vector<float> spikeHeights;

    glm::vec3 topLeft;
    glm::vec4 colour;
    float length;
    float width;

    Asteroid(glm::vec3 topLeft, glm::vec4 colour, float length, float width){
        this->topLeft = topLeft;
        this->colour = colour;
        this->length = length;
        this->width = width;

        for (int i = 0; i < 30; i++){
            int spikeGenChance = rand() % 3;
            if (spikeGenChance == 1){
                float xPos = topLeft.x + (static_cast<float>(rand()) / RAND_MAX) * width;
                float zPos = topLeft.z + (static_cast<float>(rand()) / RAND_MAX) * length;

                float height = 1 + (rand() % 6);
                glm::vec3 centre(xPos, topLeft.y + height, zPos);

                spikes.push_back(centre);
                spikeHeights.push_back(height);
            }
        }
    }
};

//material constants
const glm::vec4 STONE_COLOUR(0.412, 0.412, 0.412, 1);
const glm::vec4 MOSS_COLOUR(0, 0.678, 0.192, 1);
const glm::vec4 MAGMA_COLOUR(1, 0.369, 0.133, 1);
const glm::vec4 ICE_COLOUR(0, 0.91, 1, 1);

//game world
std::vector<Asteroid> asteroids;

void drawSpike(unsigned int shaderProgram, glm::vec3 centre, float height, glm::vec4 colour){
    const float HALF_SPIKE_WIDTH = 2.0f;

    Triangle face1(centre,
                   glm::vec3(centre.x - HALF_SPIKE_WIDTH, centre.y - height, centre.z -
                                                                             HALF_SPIKE_WIDTH),
                   glm::vec3(centre.x + HALF_SPIKE_WIDTH, centre.y - height, centre.z -
                                                                             HALF_SPIKE_WIDTH));

    Triangle face2(centre,
                   glm::vec3(centre.x + HALF_SPIKE_WIDTH, centre.y - height,
                             centre.z - HALF_SPIKE_WIDTH),
                   glm::vec3(centre.x + HALF_SPIKE_WIDTH, centre.y - height, centre.z +
                                                                             HALF_SPIKE_WIDTH));

    Triangle face3(centre,
                   glm::vec3(centre.x + HALF_SPIKE_WIDTH, centre.y - height,
                             centre.z + HALF_SPIKE_WIDTH),
                   glm::vec3(centre.x - HALF_SPIKE_WIDTH, centre.y - height, centre.z +
                                                                             HALF_SPIKE_WIDTH));
    Triangle face4(centre,
                   glm::vec3(centre.x - HALF_SPIKE_WIDTH, centre.y - height,
                             centre.z + HALF_SPIKE_WIDTH),
                   glm::vec3(centre.x - HALF_SPIKE_WIDTH, centre.y - height, centre.z -
                                                                             HALF_SPIKE_WIDTH));

    drawTriangle(face1, shaderProgram, colour);
    drawTriangle(face2, shaderProgram, colour);
    drawTriangle(face3, shaderProgram, colour);
    drawTriangle(face4, shaderProgram, colour);

}

void drawAsteroid(unsigned int shaderProgram, glm::vec3 topLeft, glm::vec4 colour,
                  float length, float width, std::vector<glm::vec3> spikes,
                  std::vector<float> spikeHeights){

    //top
    Rectangle surface(topLeft, glm::vec3(topLeft.x + width, topLeft.y, topLeft.z + length));
    drawRectangle(surface, shaderProgram, colour);

    //midpoint
    const glm::vec3 midpoint(topLeft.x + 50, topLeft.y - 100, topLeft.z + 50);

    Triangle face1(glm::vec3(topLeft.x, topLeft.y, topLeft.z),
                   glm::vec3(topLeft.x + width, topLeft.y, topLeft.z),
                   midpoint);

    Triangle face2(glm::vec3(topLeft.x, topLeft.y, topLeft.z + length),
                   glm::vec3(topLeft.x, topLeft.y, topLeft.z),
                   midpoint);

    Triangle face3(glm::vec3(topLeft.x + width, topLeft.y, topLeft.z + length),
                   glm::vec3(topLeft.x, topLeft.y, topLeft.z + length),
                   midpoint);

    Triangle face4(glm::vec3(topLeft.x + width, topLeft.y, topLeft.z + length),
                   glm::vec3(topLeft.x + width, topLeft.y, topLeft.z),
                   midpoint);

    glm::vec4 shady(colour.r - 0.25, colour.g - 0.25, colour.b - 0.25, colour.a);

    drawTriangle(face1, shaderProgram, shady);
    drawTriangle(face2, shaderProgram, shady);
    drawTriangle(face3, shaderProgram, shady);
    drawTriangle(face4, shaderProgram, shady);

    //spikes
    for (int i = 0; i < spikes.size(); i++){
        drawSpike(shaderProgram, spikes[i], spikeHeights[i], shady);
    }

    surfaces.push_back(surface);
}

void generateChunk(glm::vec3 centre, unsigned int shaderProgram){
    //init platform
    drawAsteroid(shaderProgram, glm::vec3(-50, -5.0f, -50), STONE_COLOUR, 100, 100,
                 std::vector<glm::vec3>{}, std::vector<float>{});
    Asteroid starterAsteroid(glm::vec3(-50, -5.0f, -50), STONE_COLOUR, 100, 100);
    asteroids.push_back(starterAsteroid);

    float startX = centre.x - 1000;
    float startZ = centre.z - 1000;
    float startY = centre.y - 5;

    float zIndex = startZ;
    float yIndex = startY;

    while (zIndex < centre.z + 1000) {
        float xIndex = startX;

        while (xIndex < centre.x + 1000) {
            float randomWidth = (float)(75 + (rand() % 101));
            float randomLength = (float)(75 + (rand() % 101));
            float randomHeightIncrement = (float)(-25 + (rand() % 26));

            yIndex += randomHeightIncrement;

            int colourChoice = (rand() % 4);
            glm::vec4 material;

            switch (colourChoice) {
                case 0:
                    material = STONE_COLOUR;
                    break;
                case 1:
                    material = MOSS_COLOUR;
                    break;
                case 2:
                    material = MAGMA_COLOUR;
                    break;
                case 3:
                    material = ICE_COLOUR;
                    break;
                default:
                    material = STONE_COLOUR;
                    break;
            }

            Asteroid asteroid(glm::vec3(xIndex, yIndex, zIndex),
                              material, randomWidth, randomLength);
            asteroids.push_back(asteroid);

            xIndex += randomWidth + 50;
            yIndex = -5;
        }
        zIndex += 175;
    }
}

void renderWorld(unsigned int shaderProgram){
    //render all asteroids
    for (int i = 0; i < asteroids.size(); i++){
        drawAsteroid(shaderProgram, asteroids[i].topLeft, asteroids[i].colour,
                     asteroids[i].length, asteroids[i].width, asteroids[i].spikes,
                     asteroids[i].spikeHeights);
    }
}

int main() {
    if (!glfwInit()) {
        std::cerr << "Failed to initialize GLFW" << std::endl;
        return -1;
    }

    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

#ifdef __APPLE__
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

    //generate window
    GLFWmonitor* primary = glfwGetPrimaryMonitor();
    const GLFWvidmode* mode = glfwGetVideoMode(primary);
    int screenWidth = mode->width;
    int screenHeight = mode->height;
    GLFWwindow* window = glfwCreateWindow(screenWidth, screenHeight, "Asteroid Game", nullptr, nullptr);
    if (!window) {
        std::cerr << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return -1;
    }
    glfwMakeContextCurrent(window);

    //set up mouse control
    glfwSetCursorPosCallback(window, mouseInput);
    glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

    //allow resize
    glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);

    //glad init
    if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress)) {
        std::cerr << "Failed to initialize GLAD" << std::endl;
        return -1;
    }

    glDisable(GL_CULL_FACE);
    unsigned int shaderProgram = createShaderProgram();

    //basic initial chunk
    generateChunk(cameraPos, shaderProgram);

    //background setup
    float backgroundVertices[] = {
            -1.0f,  1.0f, 0.0f,
            -1.0f, -1.0f, 0.0f,
            1.0f, -1.0f, 0.0f,

            -1.0f,  1.0f, 0.0f,
            1.0f, -1.0f, 0.0f,
            1.0f,  1.0f, 0.0f
    };

    unsigned int backgroundShaderProgram = createBackgroundShaderProgram();
    unsigned int backgroundVAO, backgroundVBO;

    glGenVertexArrays(1, &backgroundVAO);
    glGenBuffers(1, &backgroundVBO);
    glBindVertexArray(backgroundVAO);

    glBindBuffer(GL_ARRAY_BUFFER, backgroundVBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(backgroundVertices), backgroundVertices, GL_STATIC_DRAW);

    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);

    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindVertexArray(0);

    const float crossSize = 0.025f; // previously 0.05f
    const float lineWidth = 0.0025f; // previously 0.005f

    float crosshairVertices[] = {
            // vertical bar
            -lineWidth,  crossSize, 0.0f,
            -lineWidth, -crossSize, 0.0f,
            lineWidth, -crossSize, 0.0f,

            -lineWidth,  crossSize, 0.0f,
            lineWidth, -crossSize, 0.0f,
            lineWidth,  crossSize, 0.0f,

            // horizontal bar
            -crossSize,  lineWidth, 0.0f,
            -crossSize, -lineWidth, 0.0f,
            crossSize, -lineWidth, 0.0f,

            -crossSize,  lineWidth, 0.0f,
            crossSize, -lineWidth, 0.0f,
            crossSize,  lineWidth, 0.0f
    };


    unsigned int crosshairVAO, crosshairVBO, uiShaderProgram;
    glGenVertexArrays(1, &crosshairVAO);
    glGenBuffers(1, &crosshairVBO);
    glBindVertexArray(crosshairVAO);

    glBindBuffer(GL_ARRAY_BUFFER, crosshairVBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(crosshairVertices), crosshairVertices, GL_STATIC_DRAW);

    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
    glBindVertexArray(0);

    uiShaderProgram = createUIShaderProgram();


    //render loop
    while (!glfwWindowShouldClose(window)) {
        surfaces.empty();
        keyboardInput(window);

        const glm::vec4 bg(0, 0, 0.431, 1);
        glClearColor(bg.r, bg.g, bg.b, bg.a);
        glEnable(GL_DEPTH_TEST);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        //draw background
        glDepthMask(GL_FALSE);
        glUseProgram(backgroundShaderProgram);
        glBindVertexArray(backgroundVAO);
        glDrawArrays(GL_TRIANGLES, 0, 6);
        glDepthMask(GL_TRUE);

        glUseProgram(shaderProgram);

        //camera
        glm::mat4 projection = glm::perspective(glm::radians(45.0f), (float) WINDOW_WIDTH / (float) WINDOW_HEIGHT, 0.1f,
                                                500.0f);
        glm::mat4 view = glm::lookAt(cameraPos, cameraPos + cameraFront, cameraUp);
        glUniformMatrix4fv(glGetUniformLocation(shaderProgram, "view"), 1, GL_FALSE, &view[0][0]);
        glUniformMatrix4fv(glGetUniformLocation(shaderProgram, "projection"), 1, GL_FALSE, &projection[0][0]);

        if (!isPaused) {
            renderWorld(shaderProgram);
        } else {
            renderPauseMenu(shaderProgram);
        }

        glUseProgram(uiShaderProgram);
        glBindVertexArray(crosshairVAO);

        int colorLoc = glGetUniformLocation(uiShaderProgram, "uColor");
        glUniform4f(colorLoc, 1.0f, 1.0f, 1.0f, 1.0f); // white

        glDisable(GL_DEPTH_TEST); // draw on top
        glDrawArrays(GL_TRIANGLES, 0, 12);
        glEnable(GL_DEPTH_TEST);


        glfwSwapBuffers(window);
        glfwPollEvents();
    }

    glfwTerminate();
    return 0;
}